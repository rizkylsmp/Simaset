import { Op } from "sequelize";
import { Aset, SewaAset } from "../models/index.js";
import { hasPermission, PERMISSIONS } from "../middleware/auth.middleware.js";

/**
 * Get public markers for login page map (no auth required)
 * Returns minimal data: name, coordinates, status, polygon
 * GET /api/peta/public-markers
 */
export const getPublicMarkers = async (req, res) => {
  try {
    const assets = await Aset.findAll({
      where: {
        koordinat_lat: { [Op.ne]: null },
        koordinat_long: { [Op.ne]: null },
      },
      attributes: [
        "id_aset",
        "nama_aset",
        "koordinat_lat",
        "koordinat_long",
        "status",
        "status_sertifikat",
        "nomor_sertifikat",
        "lokasi",
        "luas",
        "jenis_aset",
        "kecamatan",
        "desa_kelurahan",
        "polygon_bidang",
      ],
    });

    const markers = assets.map((asset) => ({
      id: asset.id_aset,
      nama_aset: asset.nama_aset,
      latitude: parseFloat(asset.koordinat_lat),
      longitude: parseFloat(asset.koordinat_long),
      status: asset.status,
      status_sertifikat: asset.status_sertifikat || null,
      nomor_sertifikat: asset.nomor_sertifikat || null,
      lokasi: asset.lokasi || null,
      luas: asset.luas ? parseFloat(asset.luas) : null,
      jenis_aset: asset.jenis_aset || null,
      kecamatan: asset.kecamatan || null,
      desa_kelurahan: asset.desa_kelurahan || null,
      polygon: asset.polygon_bidang || null,
    }));

    res.json({
      success: true,
      data: markers,
    });
  } catch (error) {
    console.error("Error fetching public markers:", error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
};

/**
 * Get available map layers for user
 * GET /api/peta/layers
 */
export const getLayers = async (req, res) => {
  try {
    const { role } = req.user;

    // Build available layers based on role permissions
    const layers = [];

    // Layer Umum - semua role
    if (hasPermission(role, PERMISSIONS.LAYER_UMUM)) {
      layers.push({
        id: "umum",
        name: "Layer Umum",
        description: "Peta dasar dengan lokasi aset",
        enabled: true,
      });
    }

    // Layer Tata Ruang
    if (hasPermission(role, PERMISSIONS.LAYER_TATA_RUANG)) {
      layers.push({
        id: "tata_ruang",
        name: "Rencana Tata Ruang",
        description: "Layer rencana tata ruang wilayah",
        enabled: true,
      });
    }

    // Layer Potensi Bermasalah
    if (hasPermission(role, PERMISSIONS.LAYER_POTENSI_BERPERKARA)) {
      layers.push({
        id: "potensi_bermasalah",
        name: "Potensi Aset Bermasalah",
        description: "Layer aset dengan potensi sengketa/konflik/perkara",
        enabled: true,
      });
    }

    // Layer Sebaran Perkara
    if (hasPermission(role, PERMISSIONS.LAYER_SEBARAN_PERKARA)) {
      layers.push({
        id: "sebaran_perkara",
        name: "Sebaran Perkara",
        description: "Layer sebaran kasus perkara tanah",
        enabled: true,
      });
    }

    res.json({
      success: true,
      data: {
        role,
        layers,
        totalLayers: layers.length,
      },
    });
  } catch (error) {
    console.error("Error fetching layers:", error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
};

/**
 * Get all map markers
 * GET /api/peta/markers
 */
export const getMarkers = async (req, res) => {
  try {
    const { status, jenis_aset } = req.query;
    const isBPKA = req.user?.role === "bpka" || req.user?.role === "admin_bpka";

    const where = {
      sumber: isBPKA ? "BPKA" : "BPN",
      [Op.or]: [
        {
          koordinat_lat: { [Op.ne]: null },
          koordinat_long: { [Op.ne]: null },
        },
        { polygon_bidang: { [Op.ne]: null } },
      ],
    };

    if (status) where.status = status;
    if (jenis_aset) where.jenis_aset = jenis_aset;

    const assets = await Aset.findAll({
      where,
      attributes: [
        "id_aset",
        "kode_aset",
        "nib",
        "nama_aset",
        "lokasi",
        "koordinat_lat",
        "koordinat_long",
        "status",
        "status_sertifikat",
        "jenis_masalah",
        "luas",
        "jenis_aset",
        "tahun_perolehan",
        "nomor_sertifikat",
        "jenis_hak",
        "kecamatan",
        "desa_kelurahan",
        "penggunaan_saat_ini",
        "luas_lapangan",
        "opd_pengguna",
        "atas_nama",
        "status_hukum",
        "keterangan",
        "nibar",
        "kw",
        "polygon_bidang",
        "sumber",
      ],
      include: [
        {
          model: SewaAset,
          as: "sewas",
          attributes: ["id_sewa", "status", "nama_penyewa"],
          required: false,
        },
      ],
    });

    // Transform to marker format
    const markers = assets.map((asset) => {
      const plain = asset.toJSON();
      const activeSewa = plain.sewas?.find(
        (s) => s.status === "Disewakan" || s.status === "Akan Berakhir",
      );
      const availableSewa = plain.sewas?.find((s) => s.status === "Tersedia");
      const statusSewa = activeSewa
        ? "Tersewa"
        : availableSewa
          ? "Tersedia"
          : "Tidak Disewakan";

      return {
        id: plain.id_aset,
        kode: plain.kode_aset,
        nib: plain.nib || null,
        nama: plain.nama_aset,
        lokasi: plain.lokasi,
        lat: parseFloat(plain.koordinat_lat),
        lng: parseFloat(plain.koordinat_long),
        status: plain.status,
        status_sertifikat: plain.status_sertifikat || null,
        jenis_masalah: plain.jenis_masalah,
        luas: plain.luas ? parseFloat(plain.luas) : null,
        jenis: plain.jenis_aset,
        tahun: plain.tahun_perolehan,
        nomor_sertifikat: plain.nomor_sertifikat || null,
        jenis_hak: plain.jenis_hak || null,
        kecamatan: plain.kecamatan || null,
        desa_kelurahan: plain.desa_kelurahan || null,
        penggunaan_saat_ini: plain.penggunaan_saat_ini || null,
        luas_lapangan: plain.luas_lapangan
          ? parseFloat(plain.luas_lapangan)
          : null,
        opd_pengguna: plain.opd_pengguna || null,
        atas_nama: plain.atas_nama || null,
        status_hukum: plain.status_hukum || null,
        keterangan: plain.keterangan || null,
        nibar: plain.nibar || null,
        kw: plain.kw || null,
        polygon: plain.polygon_bidang || null,
        sumber: plain.sumber || null,
        status_sewa: statusSewa,
        penyewa_aktif: activeSewa ? activeSewa.nama_penyewa : null,
        id_sewa_aktif: activeSewa?.id_sewa || availableSewa?.id_sewa || null,
      };
    });

    res.json({
      success: true,
      data: markers,
      total: markers.length,
    });
  } catch (error) {
    console.error("Error fetching markers:", error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
};

/**
 * Get map statistics
 * GET /api/peta/stats
 */
export const getStats = async (req, res) => {
  try {
    const isBPKA = req.user?.role === "bpka" || req.user?.role === "admin_bpka";
    const sumberFilter = isBPKA ? "BPKA" : "BPN";

    // Count assets with coordinates
    const totalWithCoords = await Aset.count({
      where: {
        koordinat_lat: { [Op.ne]: null },
        koordinat_long: { [Op.ne]: null },
        sumber: sumberFilter,
      },
    });

    const totalWithoutCoords = await Aset.count({
      where: {
        [Op.or]: [{ koordinat_lat: null }, { koordinat_long: null }],
        sumber: sumberFilter,
      },
    });

    // Count by status (only with coordinates)
    const byStatus = await Aset.findAll({
      where: {
        koordinat_lat: { [Op.ne]: null },
        koordinat_long: { [Op.ne]: null },
        sumber: sumberFilter,
      },
      attributes: ["status", [Aset.sequelize.fn("COUNT", "*"), "count"]],
      group: ["status"],
    });

    // Total luas by status
    const luasByStatus = await Aset.findAll({
      where: {
        koordinat_lat: { [Op.ne]: null },
        koordinat_long: { [Op.ne]: null },
        sumber: sumberFilter,
      },
      attributes: [
        "status",
        [Aset.sequelize.fn("SUM", Aset.sequelize.col("luas")), "total_luas"],
      ],
      group: ["status"],
    });

    res.json({
      success: true,
      data: {
        totalMapped: totalWithCoords,
        totalUnmapped: totalWithoutCoords,
        byStatus: byStatus.reduce((acc, item) => {
          acc[item.status] = parseInt(item.dataValues.count);
          return acc;
        }, {}),
        luasByStatus: luasByStatus.reduce((acc, item) => {
          acc[item.status] = parseFloat(item.dataValues.total_luas) || 0;
          return acc;
        }, {}),
      },
    });
  } catch (error) {
    console.error("Error fetching map stats:", error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
};

/**
 * Get Layer Umum data
 * GET /api/peta/layer/umum
 */
export const getLayerUmum = async (req, res) => {
  try {
    const assets = await Aset.findAll({
      where: {
        koordinat_lat: { [Op.ne]: null },
        koordinat_long: { [Op.ne]: null },
      },
      attributes: [
        "id_aset",
        "kode_aset",
        "nama_aset",
        "lokasi",
        "koordinat_lat",
        "koordinat_long",
        "status",
        "luas",
        "jenis_aset",
      ],
    });

    const features = assets.map((asset) => ({
      type: "Feature",
      properties: {
        id: asset.id_aset,
        kode: asset.kode_aset,
        nama: asset.nama_aset,
        lokasi: asset.lokasi,
        status: asset.status,
        luas: asset.luas,
        jenis: asset.jenis_aset,
      },
      geometry: {
        type: "Point",
        coordinates: [
          parseFloat(asset.koordinat_long),
          parseFloat(asset.koordinat_lat),
        ],
      },
    }));

    res.json({
      success: true,
      data: {
        type: "FeatureCollection",
        features,
      },
      total: features.length,
    });
  } catch (error) {
    console.error("Error fetching layer umum:", error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
};

/**
 * Get Layer Tata Ruang data
 * GET /api/peta/layer/tata-ruang
 */
export const getLayerTataRuang = async (req, res) => {
  try {
    const assets = await Aset.findAll({
      where: {
        koordinat_lat: { [Op.ne]: null },
        koordinat_long: { [Op.ne]: null },
      },
      attributes: [
        "id_aset",
        "kode_aset",
        "nama_aset",
        "lokasi",
        "koordinat_lat",
        "koordinat_long",
        "status",
        "luas",
        "jenis_aset",
        "tahun_perolehan",
        "nomor_sertifikat",
      ],
    });

    const features = assets.map((asset) => ({
      type: "Feature",
      properties: {
        id: asset.id_aset,
        kode: asset.kode_aset,
        nama: asset.nama_aset,
        lokasi: asset.lokasi,
        status: asset.status,
        luas: asset.luas,
        jenis: asset.jenis_aset,
        tahun: asset.tahun_perolehan,
        sertifikat: asset.nomor_sertifikat,
      },
      geometry: {
        type: "Point",
        coordinates: [
          parseFloat(asset.koordinat_long),
          parseFloat(asset.koordinat_lat),
        ],
      },
    }));

    res.json({
      success: true,
      data: {
        type: "FeatureCollection",
        features,
      },
      total: features.length,
    });
  } catch (error) {
    console.error("Error fetching layer tata ruang:", error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
};

/**
 * Get Layer Potensi Bermasalah data
 * GET /api/peta/layer/potensi-berperkara
 */
export const getLayerPotensiBerperkara = async (req, res) => {
  try {
    const assets = await Aset.findAll({
      where: {
        koordinat_lat: { [Op.ne]: null },
        koordinat_long: { [Op.ne]: null },
        status: { [Op.in]: ["Bermasalah", "Indikasi Bermasalah"] },
      },
      attributes: [
        "id_aset",
        "kode_aset",
        "nama_aset",
        "lokasi",
        "koordinat_lat",
        "koordinat_long",
        "status",
        "jenis_masalah",
        "luas",
        "jenis_aset",
        "keterangan",
      ],
    });

    const features = assets.map((asset) => ({
      type: "Feature",
      properties: {
        id: asset.id_aset,
        kode: asset.kode_aset,
        nama: asset.nama_aset,
        lokasi: asset.lokasi,
        status: asset.status,
        luas: asset.luas,
        jenis: asset.jenis_aset,
        keterangan: asset.keterangan,
        risk_level: asset.status === "Bermasalah" ? "high" : "medium",
      },
      geometry: {
        type: "Point",
        coordinates: [
          parseFloat(asset.koordinat_long),
          parseFloat(asset.koordinat_lat),
        ],
      },
    }));

    res.json({
      success: true,
      data: {
        type: "FeatureCollection",
        features,
      },
      total: features.length,
      summary: {
        bermasalah: assets.filter((a) => a.status === "Bermasalah").length,
        indikasiBermasalah: assets.filter(
          (a) => a.status === "Indikasi Bermasalah",
        ).length,
      },
    });
  } catch (error) {
    console.error("Error fetching layer potensi bermasalah:", error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
};

/**
 * Get Layer Sebaran Perkara data
 * GET /api/peta/layer/sebaran-perkara
 */
export const getLayerSebaranPerkara = async (req, res) => {
  try {
    const assets = await Aset.findAll({
      where: {
        koordinat_lat: { [Op.ne]: null },
        koordinat_long: { [Op.ne]: null },
        status: "Bermasalah",
      },
      attributes: [
        "id_aset",
        "kode_aset",
        "nama_aset",
        "lokasi",
        "koordinat_lat",
        "koordinat_long",
        "status",
        "luas",
        "jenis_aset",
        "keterangan",
        "tahun_perolehan",
      ],
    });

    const features = assets.map((asset) => ({
      type: "Feature",
      properties: {
        id: asset.id_aset,
        kode: asset.kode_aset,
        nama: asset.nama_aset,
        lokasi: asset.lokasi,
        status: asset.status,
        luas: asset.luas,
        jenis: asset.jenis_aset,
        keterangan: asset.keterangan,
        tahun: asset.tahun_perolehan,
      },
      geometry: {
        type: "Point",
        coordinates: [
          parseFloat(asset.koordinat_long),
          parseFloat(asset.koordinat_lat),
        ],
      },
    }));

    res.json({
      success: true,
      data: {
        type: "FeatureCollection",
        features,
      },
      total: features.length,
    });
  } catch (error) {
    console.error("Error fetching layer sebaran perkara:", error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
};

/**
 * Search assets on map
 * GET /api/peta/search
 */
export const search = async (req, res) => {
  try {
    const { q, limit = 10 } = req.query;
    const isBPKA = req.user?.role === "bpka" || req.user?.role === "admin_bpka";

    if (!q || q.length < 2) {
      return res.status(400).json({
        success: false,
        error: "Query minimal 2 karakter",
      });
    }

    const assets = await Aset.findAll({
      where: {
        koordinat_lat: { [Op.ne]: null },
        koordinat_long: { [Op.ne]: null },
        sumber: isBPKA ? "BPKA" : "BPN",
        [Op.or]: [
          { nama_aset: { [Op.iLike]: `%${q}%` } },
          { kode_aset: { [Op.iLike]: `%${q}%` } },
          { nibar: { [Op.iLike]: `%${q}%` } },
          { nomor_sertifikat: { [Op.iLike]: `%${q}%` } },
          { opd_pengguna: { [Op.iLike]: `%${q}%` } },
          { lokasi: { [Op.iLike]: `%${q}%` } },
        ],
      },
      attributes: [
        "id_aset",
        "kode_aset",
        "nibar",
        "nama_aset",
        "lokasi",
        "koordinat_lat",
        "koordinat_long",
        "status",
      ],
      limit: parseInt(limit),
    });

    const results = assets.map((asset) => ({
      id: asset.id_aset,
      kode: asset.kode_aset,
      nibar: asset.nibar || null,
      nama: asset.nama_aset,
      lokasi: asset.lokasi,
      lat: parseFloat(asset.koordinat_lat),
      lng: parseFloat(asset.koordinat_long),
      status: asset.status,
    }));

    res.json({
      success: true,
      data: results,
      total: results.length,
    });
  } catch (error) {
    console.error("Error searching on map:", error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
};

/**
 * Get asset detail for map popup
 * GET /api/peta/detail/:id
 */
export const getDetail = async (req, res) => {
  try {
    const { id } = req.params;

    const asset = await Aset.findByPk(id, {
      attributes: [
        "id_aset",
        "kode_aset",
        "nama_aset",
        "lokasi",
        "koordinat_lat",
        "koordinat_long",
        "status",
        "luas",
        "jenis_aset",
        "tahun_perolehan",
        "nomor_sertifikat",
        "status_sertifikat",
        "nilai_aset",
        "keterangan",
        "foto_aset",
      ],
    });

    if (!asset) {
      return res.status(404).json({
        success: false,
        error: "Aset tidak ditemukan",
      });
    }

    res.json({
      success: true,
      data: asset,
    });
  } catch (error) {
    console.error("Error fetching asset detail:", error);
    res.status(500).json({
      success: false,
      error: error.message,
    });
  }
};
